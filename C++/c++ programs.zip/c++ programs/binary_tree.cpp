#include<iostream>
using namespace std;

struct node {
    int data;
    struct node *left;
    struct node *right;
};
struct node* createnode(int data){
    struct node *n;
    n->data = data;
    n = (struct node*)malloc(sizeof(struct node));
    n->left  = NULL;
    n->right = NULL;
    return n;
}

int main(){

    return 0;
}