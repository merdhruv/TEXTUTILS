#include <iostream>
using namespace std;

struct node{
    int data;
    struct node *next;
};
