// number triangle
#include<iostream>
using namespace std;
int main(){
    int n;
    cin>> n;
    for(int i=1;i<=n;i++){
       for(int j=1;j<=n-i;j++){
           cout<<" ";
       }
       for(int k=1;k<=i;k++){ // int j bhi use kar satke hai
           cout<<k<<" ";
       }
        cout<<endl;
    }
        
    return 0;

}
